# CodeIgniter 4 Framework

## DEMO?

http://54.254.248.107/ci/public/


## Index

![image](https://user-images.githubusercontent.com/39154644/126063500-ea68bc9e-3c8d-40e9-9631-87250c682555.png)


## CRUD Pelayananan

![image](https://user-images.githubusercontent.com/39154644/126063524-be1479e1-c3ba-4f15-b3a4-427f5631621c.png)

## Ambil antrian

![image](https://user-images.githubusercontent.com/39154644/126063540-6a95db48-4357-4792-862a-146a24b1a9d3.png)


## Result ketika berhasil ambil antrian

![image](https://user-images.githubusercontent.com/39154644/126063553-b0de4012-de4d-4c62-ab6e-1bf4ca51750f.png)


## Loket Panggil

![image](https://user-images.githubusercontent.com/39154644/126063562-9473b1ad-21da-4a1b-a2f3-4e3db1fb39ba.png)


## Result ketika berhasil memanggil antrian

![image](https://user-images.githubusercontent.com/39154644/126063598-266ed9f8-9be8-4408-add6-85a14443c290.png)

