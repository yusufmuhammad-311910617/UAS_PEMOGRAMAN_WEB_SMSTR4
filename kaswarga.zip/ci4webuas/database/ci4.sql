-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 20 Jul 2021 pada 09.27
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 7.3.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ci4`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `antrian`
--

CREATE TABLE `antrian` (
  `antrian_id` int(11) NOT NULL,
  `antrian_tanggal` varchar(50) DEFAULT NULL,
  `antrian_status` varchar(50) NOT NULL,
  `antrian_waktu_panggil` varchar(50) DEFAULT current_timestamp(),
  `antrian_waktu_selesai` varchar(50) DEFAULT NULL,
  `antrian_pelayanan_id` int(11) NOT NULL,
  `antrian_loket_id` int(11) NOT NULL,
  `antrian_last` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `antrian`
--

INSERT INTO `antrian` (`antrian_id`, `antrian_tanggal`, `antrian_status`, `antrian_waktu_panggil`, `antrian_waktu_selesai`, `antrian_pelayanan_id`, `antrian_loket_id`, `antrian_last`) VALUES
(1, '21-07-19 10:25:15', 'selesai', NULL, NULL, 4, 1, NULL),
(2, '21-07-19 10:25:22', 'selesai', NULL, NULL, 4, 1, NULL),
(3, '21-07-19 22:54:44', 'selesai', NULL, NULL, 5, 1, NULL),
(4, '21-07-19 22:54:53', 'selesai', NULL, NULL, 4, 1, NULL),
(5, '21-07-19 23:06:35', 'selesai', NULL, NULL, 5, 1, NULL),
(6, '21-07-19 23:11:22', 'selesai', NULL, NULL, 4, 1, NULL),
(7, '21-07-19 23:15:33', 'selesai', NULL, NULL, 4, 1, NULL),
(8, '21-07-19 23:52:56', 'selesai', NULL, NULL, 5, 1, NULL),
(9, '21-07-19 23:57:24', 'berlansung', NULL, NULL, 4, 1, NULL),
(10, '21-07-20 00:36:05', 'mengantri', NULL, NULL, 4, 1, NULL),
(11, '21-07-20 02:04:33', 'mengantri', NULL, NULL, 4, 1, NULL),
(12, '21-07-20 02:09:18', 'mengantri', NULL, NULL, 4, 1, NULL),
(13, '21-07-20 02:15:00', 'mengantri', NULL, NULL, 4, 1, NULL),
(14, '21-07-20 02:18:31', 'mengantri', NULL, NULL, 4, 1, NULL),
(15, '21-07-20 02:19:55', 'mengantri', NULL, NULL, 4, 1, NULL),
(16, '21-07-20 02:22:27', 'mengantri', NULL, NULL, 4, 1, NULL),
(17, '21-07-20 02:23:27', 'mengantri', NULL, NULL, 4, 1, NULL),
(18, '21-07-20 02:25:17', 'mengantri', NULL, NULL, 4, 1, NULL),
(19, '21-07-20 02:26:05', 'mengantri', NULL, NULL, 4, 1, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2021-07-11-044811', 'App\\Database\\Migrations\\Pelayanan', 'default', 'App', 1625979235, 1),
(2, '2021-07-11-054601', 'App\\Database\\Migrations\\Loket', 'default', 'App', 1625982577, 2),
(3, '2021-07-11-070851', 'App\\Database\\Migrations\\Loket', 'default', 'App', 1625987345, 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelayanan`
--

CREATE TABLE `pelayanan` (
  `pelayanan_id` int(11) UNSIGNED NOT NULL,
  `pelayanan_name` varchar(100) NOT NULL,
  `pelayanan_code` varchar(100) NOT NULL,
  `pelayanan_description` text DEFAULT NULL,
  `jenis_kelamin` enum('pria','wanita') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `pelayanan`
--

INSERT INTO `pelayanan` (`pelayanan_id`, `pelayanan_name`, `pelayanan_code`, `pelayanan_description`, `jenis_kelamin`) VALUES
(18, 'Yusuf', '31191617', 'tayu', 'pria'),
(19, 'dani', '31191618', 'tayu', 'pria'),
(24, 'santoso', '31191619', 'pati', 'pria'),
(25, 'dewi', '311916110', 'tayu', 'wanita');

-- --------------------------------------------------------

--
-- Struktur dari tabel `upload_gambar`
--

CREATE TABLE `upload_gambar` (
  `id` int(5) NOT NULL,
  `judul` varchar(40) NOT NULL,
  `gambar` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `upload_gambar`
--

INSERT INTO `upload_gambar` (`id`, `judul`, `gambar`) VALUES
(3, 'yusuf', 'yusup_2.jpeg'),
(4, 'cahyono', 'motor_1.jpeg'),
(5, 'teguh', 'iconfinder_3_avatar_2754579.png');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `antrian`
--
ALTER TABLE `antrian`
  ADD PRIMARY KEY (`antrian_id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pelayanan`
--
ALTER TABLE `pelayanan`
  ADD PRIMARY KEY (`pelayanan_id`);

--
-- Indeks untuk tabel `upload_gambar`
--
ALTER TABLE `upload_gambar`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `antrian`
--
ALTER TABLE `antrian`
  MODIFY `antrian_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `pelayanan`
--
ALTER TABLE `pelayanan`
  MODIFY `pelayanan_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT untuk tabel `upload_gambar`
--
ALTER TABLE `upload_gambar`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
